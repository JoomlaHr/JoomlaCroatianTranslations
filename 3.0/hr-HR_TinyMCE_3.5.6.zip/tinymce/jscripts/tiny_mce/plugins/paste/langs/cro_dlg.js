tinyMCE.addI18n('cro.paste_dlg',{"word_title":"Koristite CTRL+V na tipkovnici da zalijepite tekst u prozor.",
"text_linebreaks":"Zadr\u017ei prijelome",
"text_title":"Koristite CTRL+V na tipkovnici da zalijepite tekst u prozor."});