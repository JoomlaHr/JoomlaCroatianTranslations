tinyMCE.addI18n('cro.advhr_dlg',{size:"Visina",
noshade:"Bez sjene",
width:"\u0160irina",
normal:"Normalno",
widthunits:"Jedinice"});