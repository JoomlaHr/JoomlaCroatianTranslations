tinyMCE.addI18n('cro.autosave',{
restore_content: "Vra\u0107anje automatski spremljenog sadr�aja",
warning_message: "Ako vratite spremljeni sadr\u017eaj, izgubit \u0107ete sav sadr\u017eaj koja je trenutno u editoru.\n\nJeste li sigurni da \u017eelite vratiti spremljeni sadr\u017eaj?"
});