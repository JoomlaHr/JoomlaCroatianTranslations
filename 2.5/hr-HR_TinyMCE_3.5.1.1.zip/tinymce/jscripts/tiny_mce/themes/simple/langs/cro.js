tinyMCE.addI18n('cro.simple',{"cleanup_desc":"Po\u010disti neuredni kod",
"redo_desc":"Ponovi (Ctrl+Y)",
"undo_desc":"Poni\u0161ti (Ctrl+Z)",
"numlist_desc":"Numerirana lista",
"bullist_desc":"Nenumerirana lista",
"striketrough_desc":"Precrtano",
"underline_desc":"Podcrtano (Ctrl U)",
"italic_desc":"Uko\u0161eno (Ctrl I)",
"bold_desc":"Podebljano (Ctrl B)"});