tinyMCE.addI18n('cro.advhr_dlg',{
normal:"Normalno",
width:"\u0160irina",
widthunits:"Jedinice",
size:"Visina",
noshade:"Bez sjene"
});