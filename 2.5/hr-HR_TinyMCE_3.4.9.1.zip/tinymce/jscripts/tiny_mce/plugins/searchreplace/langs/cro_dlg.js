tinyMCE.addI18n('cro.searchreplace_dlg',{
searchnext_desc:"Prona\u0111i opet",
notfound:"Pretra\u017eivanje je zavr\u0161eno. Tra\u017eeni tekst nije prona\u0111en.",
search_title:"Prona\u0111i",
replace_title:"Prona\u0111i/Zamijeni",
allreplaced:"Sva pojavljivanja tra\u017eenog teksta su zamijenjena.",
findwhat:"Prona\u0111i tekst",
replacewith:"Zamijeni sa",
direction:"Smjer",
up:"Gore",
down:"Dolje",
mcase:"Usporedi velika/mala slova",
findnext:"Prona\u0111i sljede\u0107e",
replace:"Zamijeni",
replaceall:"Zamijeni sve"
});