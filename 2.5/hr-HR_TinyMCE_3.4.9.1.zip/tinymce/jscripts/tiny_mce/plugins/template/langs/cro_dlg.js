tinyMCE.addI18n('cro.template_dlg',{
title:"Predlo\u0161ci",
label:"Predlo\u017eak",
desc_label:"Opis",
desc:"Umetni predefinirani sadr\u017eaj predlo\u0161ka",
select:"Odaberite predlo\u017eak",
preview:"Predpregled",
warning:"Warning: A\u017euriranje predlo\u0161ka novim mo\u017ee uzrokovati gubitak podataka.",
mdate_format:"%d.%m.%Y %H:%M:%S",
cdate_format:"%d.%m.%Y %H:%M:%S",
months_long:"Sije\u010danj,Velja\u010da,O\u017eujak,Travanj,Svibanj,Lipanj,Srpanj,Kolovoz,Rujan,Listopad,Studeni,Prosinac",
months_short:"Sij,Velj,O\u017eu,Tra,Svi,Lip,Srp,Kol,Ruj,Lis,Stu,Pro",
day_long:"Nedjelja,Ponedjeljak,Utorak,Srijeda,\u010Cetvrtak,Petak,Subota,Nedjelja",
day_short:"Ned,Pon,Uto,Sri,\u010Cet,Pet,Sub,Ned"
});