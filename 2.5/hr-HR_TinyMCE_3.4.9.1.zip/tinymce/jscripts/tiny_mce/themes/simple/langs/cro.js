tinyMCE.addI18n('cro.simple',{
bold_desc:"Podebljano (Ctrl+B)",
italic_desc:"Uko\u0161eno (Ctrl+I)",
underline_desc:"Podcrtano (Ctrl U)",
striketrough_desc:"Precrtano",
bullist_desc:"Nenumerirana lista",
numlist_desc:"Numerirana lista",
undo_desc:"Poni\u0161ti (Ctrl+Z)",
redo_desc:"Ponovi (Ctrl+Y)",
cleanup_desc:"Po\u010Disti neuredni k\u00F4d"
});