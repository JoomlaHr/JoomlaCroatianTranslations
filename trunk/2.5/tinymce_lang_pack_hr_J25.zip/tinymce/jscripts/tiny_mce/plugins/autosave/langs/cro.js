tinyMCE.addI18n('cro.autosave',{
restore_content: "Povrati sadr\u017Eaj koji je automatski spremljen.",
warning_message: "Ako povratite spremljeni sadr\u017Eaj, izgubiti \u0107ete sav sadr\u017Eaj koji se trenutno nalazi u editoru.\n\nJeste li sigurni da \u017Eelite povratiti spremljeni sadr\u017Eaj?"
});